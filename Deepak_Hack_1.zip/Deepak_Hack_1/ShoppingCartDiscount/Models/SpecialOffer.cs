﻿namespace ShoppingCartDiscount.Models
{
    public class Discount_Amount
    {
        public int Quantity { get; set; }
        public decimal Discount_AmountAmount { get; set; }
    }
}
